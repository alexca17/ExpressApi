import React, { useState, useEffect } from "react";
import { useHistory, useLocation } from "react-router-dom";
import axios from "axios";
import "./AddEdit.css";
import { toast } from "react-toastify";
import { useParams } from "react-router-dom";

const initialState = {
  name: "",
  email: "",
  contact: "",
};

const AddEdit = () => {
  //my hook
  const [state, setState] = useState(initialState);

  //destructurar mi objeto
  let { name, email, contact } = initialState;

  //Redireccionar
  const history = useHistory();

  const { id } = useParams();

  useEffect(() => {
    if (id) {
      getSingleUser(id);
    }
  }, [id]);

  const getSingleUser = async (id) => {
    const res = await axios.get(`http://localhost:5000/user/${id}`);
    if (res.status === 200) {
      setState({ ...res.data[0] });
    }
  };

  const addContact = async (data) => {
    const res = await axios.post("http://localhost:5000/user", data);
    if (res.status === 200) {
      toast.success(res.data);
    } else {
      toast.error(res.data);
    }
  };

  const handleSubmit = (e) => {
    //name = e.target.name;
    //email = e.target.email;
    //contact = e.target.contact;
    e.preventDefault();

    if (!name || !email || !contact) {
      toast.error("Please provide value into each input field");
    } else {
      addContact(state);
      setTimeout(() => history.push("/"), 500);
    }
  };

  return (
    <div style={{ marginTop: "100px" }}>
      <form
        style={{
          margin: "auto",
          padding: "15px",
          maxWidth: "400px",
          alignContent: "center",
        }}
        onSubmit={handleSubmit}
      >
        <label htmlFor="name">Name</label>
        <input
          type="text"
          id="name"
          name="name"
          placeholder="Type the name here..."
          defaultValue={name}
        />
        <label htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          placeholder="Type your Email here..."
          defaultValue={email}
        />
        <label htmlFor="contact">Contact</label>
        <input
          type="number"
          id="contact"
          name="contact"
          placeholder="Type your contact here..."
          defaultValue={contact}
        />
        <input type="submit" value={id ? "Update": "Add"} />
      </form>
    </div>
  );
};

export default AddEdit;
